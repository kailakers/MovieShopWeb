﻿using System;

namespace MovieShop.Infrastructure
{
    public class Class1
    {
    }
}