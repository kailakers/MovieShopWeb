namespace MovieShop.Core.Models
{
    public class ReviewRequestModel
    {
        public int UserId { get; set; }
        public int MovieId { get; set; }
        public string ReviewText { get; set; }
        public decimal? Rating { get; set; }
    }
}