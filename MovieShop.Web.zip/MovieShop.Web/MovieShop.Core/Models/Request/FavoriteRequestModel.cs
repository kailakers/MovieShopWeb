namespace MovieShop.Core.Models
{
    public class FavoriteRequestModel
    {
        public int userId { get; set; }
        public int movieId { get; set; }
    }
}