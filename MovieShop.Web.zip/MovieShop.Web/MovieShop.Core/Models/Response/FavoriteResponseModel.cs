namespace MovieShop.Core.Models
{
    public class FavoriteResponseModel
    {
        public int UserId { get; set; }
        public int MovieId { get; set; }
    }
}