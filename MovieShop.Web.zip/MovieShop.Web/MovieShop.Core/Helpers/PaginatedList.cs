namespace MovieShop.Core.Helpers
{
    public class PaginatedList<T> where T:class
    {
        
    }
}