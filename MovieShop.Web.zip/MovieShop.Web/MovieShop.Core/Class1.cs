﻿using System;

namespace MovieShop.Core
{
    public class Class1
    {
    }
}